package com.test.trade;

import java.text.ParseException;
import java.time.LocalDate;
import java.util.Comparator;
import java.util.Map;
import java.util.Map.Entry;
import java.util.TreeMap;
import java.util.concurrent.ConcurrentHashMap;

public class TradeStore {
	
	private Map<Integer,Trade> tradeStoreMap = new ConcurrentHashMap<>();

	public boolean addToTradeStore(Trade trade) throws ParseException {
		boolean addFlag = false;
		try {
		if(!validations(trade)) {
			Entry<Integer, Trade> entry = tradeStoreMap.entrySet()
			        .stream()
			        .filter(e -> e.getValue().getTradeId().equals(trade.getTradeId()))
			        .max(Map.Entry.comparingByValue(Comparator.comparingInt(Trade::getVersion)))
			        .orElse(null);

					if(entry!= null && entry.getValue().getVersion().equals(trade.getVersion())) {
						tradeStoreMap.put(entry.getKey(),trade);
					}else {
					tradeStoreMap.put(trade.getId(),trade);
					}
					addFlag = true;
		}
		}catch(Exception e) {
			e.printStackTrace();
			addFlag = false;
		}
		return addFlag;
	}
	
	public Map<Integer,Trade> getTrades(){
        Map<Integer, Trade> sorted = new TreeMap<>(new TradeComparator(tradeStoreMap));
        sorted.putAll(tradeStoreMap);
        return sorted;
	}

	private boolean validations(Trade trade) throws ParseException {

		for(Map.Entry<Integer, Trade> entry :  tradeStoreMap.entrySet()) {
			if(entry.getValue().getTradeId().equals(trade.getTradeId()) && entry.getValue().getVersion()>trade.getVersion()){
				return true;
			}else if(trade.getMaturityDate().isBefore(LocalDate.now())) {
				System.out.println("falls under this criteria trade id"+trade.getId());
				return true;
			}
		}
		return false;
	}
	public boolean updateExpiryFlag() {
		for(Map.Entry<Integer, Trade> entry :  tradeStoreMap.entrySet()) {
			if(entry.getValue().getMaturityDate().isEqual(LocalDate.now())) {
				entry.getValue().setExpired("Y");
				tradeStoreMap.put(entry.getKey(), entry.getValue());
				System.out.println("updating expirty flag for tradeid"+ entry.getValue().getTradeId());
				return true;
			}
		}
		return false;
	}
}

