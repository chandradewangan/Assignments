package com.test.trade;

import java.util.Comparator;
import java.util.Map;

public class TradeComparator implements Comparator<Integer> {
	Map<Integer, Trade> map;
	public TradeComparator(Map<Integer, Trade> map) {
		this.map = map;
	}
	
	public int compare(Integer t1, Integer t2) {
	     int tradeIdCompare = map.get(t1).getTradeId().compareTo(map.get(t2).getTradeId());
	     if (tradeIdCompare != 0) {
	        return tradeIdCompare;
	     } else {
	     return  map.get(t2).getVersion().compareTo(map.get(t1).getVersion());
	     }
	  }

}
