package com.test.trade;

import java.lang.reflect.Field;
import java.text.ParseException;
import java.time.LocalDate;
import java.util.Map;

import org.junit.Assert;
import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.MockitoAnnotations;
import org.powermock.core.classloader.annotations.PrepareForTest;
import org.powermock.modules.junit4.PowerMockRunner;

@RunWith(PowerMockRunner.class)
@PrepareForTest({})
public class TradeStoreTest {
	@InjectMocks
	private TradeStore mockTradeStore;
	
	@Mock
	private Map<Integer,Trade> mockTradeStoreMap;
	
	private TradeStore tradeStore;

	private Field tradeStoreMap;
	
	@Before
	public void setup() throws ParseException, NoSuchFieldException{
		MockitoAnnotations.initMocks(this);
		tradeStore = new TradeStore();
		tradeStore.addToTradeStore(new Trade(1,12l,1,"CP-1","B-1",LocalDate.now().plusDays(1),LocalDate.now(),"N"));
		tradeStore.addToTradeStore(new Trade(5,16l,1,"CP-5","B-5",LocalDate.now().plusDays(2),LocalDate.now(),"N"));
		tradeStore.addToTradeStore(new Trade(2,13l,1,"CP-2","B-2",LocalDate.now().plusDays(3),LocalDate.now(),"N"));
		tradeStore.addToTradeStore(new Trade(3,14l,1,"CP-3","B-3",LocalDate.now().plusDays(4),LocalDate.now(),"N"));
		tradeStore.addToTradeStore(new Trade(4,14l,2,"CP-4","B-4",LocalDate.now().plusDays(5),LocalDate.now(),"N"));
		tradeStore.addToTradeStore(new Trade(10,18l,2,"CP-18","B-18",LocalDate.now(),LocalDate.now(),"N"));
		tradeStoreMap = TradeStore.class.getDeclaredField("tradeStoreMap");
		tradeStoreMap.setAccessible(true);
	}

	@SuppressWarnings("unchecked")
	@Test
	public void addToTradeStoreTest() throws IllegalAccessException  {
		mockTradeStoreMap=(Map<Integer, Trade>) tradeStoreMap.get(tradeStore);
		Assert.assertEquals(6,mockTradeStoreMap.size());
	}
	
	@Test
	public void getTradesTest() {
		Assert.assertEquals(6,tradeStore.getTrades().size());
	}
	
	@Test
	public void validationForLowerVersionTest() throws ParseException {
		Assert.assertEquals(false,tradeStore.addToTradeStore(new Trade(7,14l,1,"CP-7","B-7",LocalDate.now().plusDays(1),LocalDate.now(),"N")));	
	}
	
	@SuppressWarnings("unchecked")
	@Test
	public void validationForSameVersionTest() throws ParseException, IllegalAccessException {
		Assert.assertEquals(true,tradeStore.addToTradeStore(new Trade(6,14l,2,"CP-6","B-6",LocalDate.now(),LocalDate.now(),"N")));
		mockTradeStoreMap=(Map<Integer, Trade>) tradeStoreMap.get(tradeStore);
		Assert.assertEquals(Long.valueOf(14l), mockTradeStoreMap.get(4).getTradeId());
		Assert.assertEquals(Integer.valueOf(2), mockTradeStoreMap.get(4).getVersion());
	}
	
	@Test
	public void validationForLessMaturityDateTest() throws ParseException {
		Assert.assertEquals(false,tradeStore.addToTradeStore(new Trade(8,17l,1,"CP-9","B-9",LocalDate.now().minusDays(1),LocalDate.now(),"N")));
	}
	
	@SuppressWarnings("unchecked")
	@Test
	public void expiryFlagTest() throws IllegalAccessException {
		Assert.assertEquals(true,tradeStore.updateExpiryFlag());
		mockTradeStoreMap=(Map<Integer, Trade>) tradeStoreMap.get(tradeStore);
		for(Map.Entry<Integer, Trade> entry :  mockTradeStoreMap.entrySet()) {
			if(entry.getValue().getMaturityDate().equals(LocalDate.now())) {
				Assert.assertEquals("Y",entry.getValue().getExpired());
			}
		}
	}
	
}
